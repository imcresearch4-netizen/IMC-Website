
class XCrosser:
    def __init__(self):
        print('X Crosser Contructor')
