from rga.xgene import XGene
from rga.xchromo import XChromo
# from sklearn import svm
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.datasets import make_classification
import numpy as np
import random
# from rga.xcrosser import XCrosser
# from rga.xmutator import XMutator


class XGA:
    def __init__(self):
        self.config = {}
        self.population = []
        print('XGA Contructor')

    def cross(self, mChild, fChild):
        np.random.rand()
        for i in range(10):
            print('testing ' + str(i))

    def mutate(self, _chromo):
        _cloned = _chromo.copy()
        size = len(_cloned.genes)
        mutationCount = int(size / 4)
        for i in range(mutationCount):
            index = np.random.uniform(0, size)
            _cloned[index].value = np.random.rand()
        return _cloned

    def configure(self, _config):
        """
        Configures parameters for Reweighted GA
        {_config} | Dictionary of configuration expected
        """
        self.config = _config
        print(_config)
        print('RGA Configured')

    def setPopulation(self, _chromosomes):
        """
        Sets Population 
        {_chromosomes} | A list of chromosome expected
        """
        population = _chromosomes
        print("Population is Set !")

    def reweightFeature(self, _chromo, _feature):
        _chromo.genes[_feature] = np.random.rand()

    def reweight(self, _chromo):
        for gene in _chromo:
            self.reweightFeature(_chromo, gene.name)

    def pooledSelection(self):
        pass

    def start(self):
        """
        Starts the Reweighted GA
        """
        mutationRate = self.config['mutation_rate']

        pool = random.sample(self.population, self.config['poolSize'])
        for i in range(self.config['poolSize']):
            chromo = pool[i]
            copyChromo = chromo.copy()
            if np.random.rand() <= mutationRate:
                self.mutate(copyChromo)
            else:
                rChromo = random.choice(pool)
                self.cross(copyChromo, rChromo.copy())

            # Actual fitness is for the chromosome under consideration
            actualFitness = chromo.evalFitness()
            copyFitness = chromo.evalFitness()

            if copyFitness > actualFitness:
                chromo.fitness = copyFitness

        self.pooledSelection()
