import numpy as np


class XMutator:
    def __init__(self):
        print('X Mutator Contructor')

    def mutate(self, _chromo):
        _cloned = _chromo.copy()
        size = len(_cloned.genes)
        mutationCount = int(size / 4)
        for i in range(mutationCount):
            index = np.random.uniform(0, size)
            _cloned[index].value = np.random.rand()
        return _cloned
