from rga.xgene import XGene
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification


class XChromo:
    def __init__(self, _genes):
        self.genes = []
        self.fitness = 0.0001
        self.label = ''
        self.chromize(_genes)

    def chromize(self,  _genes):
        self.genes = _genes

    def evalSVM(self):
        return 1010

    def evalRF(self):
        return 2020

    def evalFitness(self):
        return (self.evalSVM() + self.evalRF()) / 2
