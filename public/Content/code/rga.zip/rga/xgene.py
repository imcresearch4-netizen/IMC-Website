class XGene:
    def __init__(self):
        self.name = ''
        self.weight = 1
        self.value = 0
        print('XGene Contruct')
